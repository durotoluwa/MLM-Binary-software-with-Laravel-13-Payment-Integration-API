<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use App\Models\product_order;
use App\Models\product_order_item;
use App\Helpers\MlmBonusHelper;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Models\userpackage;
use App\Models\User;
use App\Models\Package;
use Carbon\Carbon;
use App\Models\Bonus; 
use App\Models\Product; 
use App\Models\package_product_orders;
use Yabacon\Paystack; 
use App\Models\incentives;
use App\Models\incentive_settings;






 

class userpackageController extends Controller
{



public function showPurchaseForm($id)
{
    $package = Package::findOrFail($id);
    $user = Auth::user();

    // Check if user already purchased this package
    $existing = userpackage::where('user_id', $user->id)
        ->where('package_id', $id)
        ->first();

    if ($existing) {
        return redirect()->back()->with('error', 'You have already purchased this package.');
    }

    // Get the user's last purchased package (previous upgrade)
    $previous = userpackage::where('user_id', $user->id)
        ->latest('id') // or created_at if you track purchases
        ->first();

    $finalPrice = $package->price;

    if ($previous) {
        $previousPackage = Package::find($previous->package_id);
        if ($previousPackage) {
            // Deduct previous package price
            $finalPrice = max($package->price - $previousPackage->price, 0);
        }
    }
  $products = Product::all(); 
    return view('user.purchase-package', compact('package', 'user', 'finalPrice', 'products'));
}



public function selectProducts($package_id)
{
    $package = Package::findOrFail($package_id);
    $products = Product::all();  
    return view('user.package-products', compact('package', 'products'));
}

 



 
 





public function purchasenew(Request $request)
{
    $user = Auth::user();

    $validator = Validator::make($request->all(), [
        'package_id' => 'required|exists:package,id',
        'payment_method' => 'required|in:wallet,bank,online',
        'transaction_pin' => 'required_if:payment_method,wallet',
        'payment_proof' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        'acctName' => 'nullable|string',
        'bankName' => 'nullable|string',
        'amount' => 'nullable|numeric',
        'product' => 'required|array',
        'product.*.id' => 'required|exists:product,id',
        'product.*.qty' => 'nullable|integer|min:0',
    ]);

    if ($validator->fails()) {
        return back()->withErrors($validator)->withInput();
    }

    $newPackage = Package::find($request->package_id);
    if (!$newPackage) {
        return back()->with('error', 'Selected package not found.');
    }

    $maxBottles = (int) $newPackage->bottle;
    $maxCpts = (float) $newPackage->cpts;

    $validator->after(function ($validator) use ($request, $maxBottles, $maxCpts) {
        $rows = $request->product ?? [];
        $selected = array_filter($rows, fn($r) => !empty($r['qty']) && (int)$r['qty'] > 0);

        if (count($selected) === 0) {
            $validator->errors()->add('product', 'Please select products with valid quantities.');
            return;
        }

        $totalQty = 0;
        $totalCpts = 0.0;

        foreach ($selected as $index => $row) {
            $qty = (int) $row['qty'];
            $product = Product::find($row['id']);
            if (!$product) {
                $validator->errors()->add("product.$index.id", 'Invalid product selected.');
                continue;
            }

            $totalQty += $qty;
            $totalCpts += ((float) $product->cpts) * $qty;
        }

        if ($totalQty !== $maxBottles) {
            $validator->errors()->add('product', "You must select exactly {$maxBottles} bottles; you selected {$totalQty}.");
        }

        if ($totalCpts !== $maxCpts) {
            $validator->errors()->add('product', "Total CPTs must be exactly {$maxCpts}; you selected {$totalCpts}.");
        }
    });

    if ($validator->fails()) {
        return back()->withErrors($validator)->withInput();
    }

    $previousPackage = userpackage::where('user_id', $user->id)
        ->where('status', 'approved')
        ->latest()
        ->first();

    if ($previousPackage && $newPackage->id <= $previousPackage->package_id) {
        return back()->with('error', 'You can only upgrade to a higher package.');
    }

    $amountToPay = $newPackage->price;
    $ctpToAdd = $newPackage->cpts;
    $isUpgrade = false;
    $previousPackageId = null;

    if ($previousPackage) {
        $isUpgrade = true;
        $previousPackageId = $previousPackage->package_id;
        $previous = Package::find($previousPackageId);
        $amountToPay -= $previous->price;
        $ctpToAdd -= $previous->cpts;
    }

    $amountToPay += ($newPackage->apc * $newPackage->bottle);

    // === WALLET PAYMENT ===
    if ($request->payment_method === 'wallet') {

        if ($request->transaction_pin !== $user->transaction_pin) {
            return back()->withErrors(['transaction_pin' => 'Invalid transaction PIN.'])->withInput();
        }

        if ($user->deposit_wallet_balance < $amountToPay) {
            return back()->with('error', 'Insufficient wallet balance.');
        }

      DB::transaction(function () use ($user, $newPackage, $previousPackageId, $amountToPay, $ctpToAdd, $request, $isUpgrade) {

    // Deduct wallet
    $user->deposit_wallet_balance -= $amountToPay;

    // === Normalize rank: reset to Regular if not in incentive ranks ===
  
// Normalize rank
$incentiveRanks = DB::table('incentive_settings')->pluck('rank')->toArray();
$rankToSet = in_array($user->user_rank, $incentiveRanks) ? $user->user_rank : 'Regular';

// Non-numeric updates
// Refresh to get latest DB values
$user->increment('total_ctp', $ctpToAdd);
$user->increment('p_c_cpts', $ctpToAdd);
$user->increment('current_p_c_cpts', $ctpToAdd);
$user->increment('current_c_cpts', $ctpToAdd);
$user->decrement('deposit_wallet_balance', $amountToPay);

$user->update([
    'user_plan' => $newPackage->packageName,
    'status'    => 'active',
    'user_rank' => $rankToSet,
]);



 

    // Trigger incentive check for direct upline
    if ($user->parent_id) {
        $parent = User::find($user->parent_id);
        if ($parent) {
            $this->evaluateUserIncentives($parent);
        }
    }

    // Add CPT to uplines + matching bonus
    $this->addCTPToUplines($user, $ctpToAdd, function ($uplineUser) use ($ctpToAdd) {
        $this->handleMatchingBonus($uplineUser, $ctpToAdd);
    });

    // Trigger matching for buyer
    $this->handleMatchingBonus($user, $ctpToAdd);

    // Create package order
    $userpackage = userpackage::create([
        'user_id'              => $user->id,
        'package_id'           => $newPackage->id,
        'previous_package_id'  => $previousPackageId,
        'amount_paid'          => $amountToPay,
        'payment_method'       => 'wallet',
        'status'               => 'approved',
        'package_order_status' => 'approved',
    ]);

    // Save ordered products
    foreach ($request->product as $row) {
        $qty = (int) ($row['qty'] ?? 0);
        if ($qty <= 0) continue;

        DB::table('package_product_orders')->insert([
            'user_id'          => $user->id,
            'package_id'       => $newPackage->id,
            'product_id'       => $row['id'],
            'package_order_id' => $userpackage->id,
            'qty'              => $qty,
            'created_at'       => now(),
            'updated_at'       => now(),
        ]);
    }

    // Referral bonus
    $this->payReferralBonus($user, $newPackage->price, $isUpgrade, $previousPackageId);
});



        return redirect()->route('user.package')->with('success', 'Package purchased successfully using wallet.');
    }

    // === BANK PAYMENT ===
    if ($request->payment_method === 'bank') {
        if (!$request->hasFile('payment_proof')) {
            return back()->with('error', 'Please upload proof of payment.');
        }

        $image = $request->file('payment_proof');
        $filename = time() . '_' . Str::uuid() . '.' . $image->getClientOriginalExtension();
        $image->move(public_path('payment_proofs'), $filename);
        $paymentProofPath = 'payment_proofs/' . $filename;

        DB::transaction(function () use ($request, $user, $newPackage, $previousPackageId, $amountToPay, $paymentProofPath) {
            $userpackage = userpackage::create([
                'user_id' => $user->id,
                'package_id' => $newPackage->id,
                'previous_package_id' => $previousPackageId,
                'amount_paid' => $request->amount,
                'payment_method' => 'bank',
                'acctName' => $request->acctName,
                'total_amount_package' => $request->total_amount_package,
                'bankName' => $request->bankName,
                'payment_proof' => $paymentProofPath,
                'status' => 'pending',
                'package_order_status' => 'pending',
            ]);

            foreach ($request->product as $row) {
                $qty = (int) ($row['qty'] ?? 0);
                if ($qty <= 0) continue;

                DB::table('package_product_orders')->insert([
                    'user_id' => $user->id,
                    'package_id' => $newPackage->id,
                    'product_id' => $row['id'],
                    'package_order_id' => $userpackage->id,
                    'qty' => $qty,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        });

        return redirect()->route('user.package')->with('success', 'Package submitted for approval. Awaiting admin confirmation.');
    }

    // === ONLINE PAYMENT — PAYSTACK ===
    if ($request->payment_method === 'online') {
        try {
            $request->validate([
                'paystack_reference' => 'required|string',
                'package_id' => 'required|exists:package,id',
                'product' => 'required|array',
                'product.*.id' => 'required|exists:product,id',
                'product.*.qty' => 'nullable|integer|min:0',
            ]);

            $reference = $request->paystack_reference;
            $productSelection = $request->product;
            $newPackage = Package::find($request->package_id);

            if (!$newPackage) {
                \Log::error("Package not found for ID: {$request->package_id}");
                return response()->json([
                    'status' => 'error',
                    'message' => 'Selected package not found.',
                ], 404);
            }

            // Verify Paystack payment
            $verifyResponse = Http::withOptions(['verify' => false])
                ->withHeaders([
                    'Authorization' => 'Bearer ' . env('PAYSTACK_SECRET_KEY'),
                    'Accept' => 'application/json',
                ])
                ->get("https://api.paystack.co/transaction/verify/{$reference}");

            if (!$verifyResponse->successful() || ($verifyResponse['data']['status'] ?? '') !== 'success') {
                \Log::error('Paystack verification failed', ['response' => $verifyResponse->body()]);
                return response()->json([
                    'status' => 'error',
                    'message' => 'Payment verification failed.',
                ], 400);
            }

            $amountPaid = $verifyResponse['data']['amount'] / 100;
            $ctpToAdd = $newPackage->cpts;
            $previousPackage = userpackage::where('user_id', $user->id)
                ->where('status', 'approved')
                ->latest()
                ->first();

            $isUpgrade = false;
            $previousPackageId = null;

            if ($previousPackage && $newPackage->id > $previousPackage->package_id) {
                $isUpgrade = true;
                $previousPackageId = $previousPackage->package_id;
                $previous = Package::find($previousPackageId);
                $ctpToAdd -= $previous->cpts;
            }

            DB::transaction(function () use ($user, $newPackage, $previousPackageId, $amountPaid, $ctpToAdd, $productSelection, $isUpgrade) {

                // Normalize rank: reset to Regular if not in incentive ranks
                $incentiveRanks = DB::table('incentive_settings')->pluck('rank')->toArray();
                $rankToSet = in_array($user->user_rank, $incentiveRanks) ? $user->user_rank : 'Regular';

                // Update buyer CPT and status
                $user->update([
                    'total_ctp'        => $user->total_ctp + $ctpToAdd,
                    'p_c_cpts'         => $user->p_c_cpts + $ctpToAdd,
                    'current_p_c_cpts' => $user->current_p_c_cpts + $ctpToAdd,
                    'current_c_cpts'   => $user->current_c_cpts + $ctpToAdd,
                    'user_plan'        => $newPackage->packageName,
                    'status'           => 'active',
                    'user_rank'        => $rankToSet,
                ]);

                // Update uplines (once — fixed) + evaluate parent incentives
                $this->addCTPToUplines($user, $ctpToAdd, function ($uplineUser) use ($ctpToAdd) {
                    $this->handleMatchingBonus($uplineUser, $ctpToAdd);
                });

                if ($user->parent_id) {
                    $parent = User::find($user->parent_id);
                    if ($parent) {
                        $this->evaluateUserIncentives($parent);
                    }
                }

                // Create package order
                $userPackage = userpackage::create([
                    'user_id' => $user->id,
                    'package_id' => $newPackage->id,
                    'previous_package_id' => $previousPackageId,
                    'amount_paid' => $amountPaid,
                    'payment_method' => 'online',
                    'status' => 'approved',
                    'package_order_status' => 'approved',
                ]);

                // Save ordered products
                foreach ($productSelection as $row) {
                    $qty = (int) ($row['qty'] ?? 0);
                    if ($qty <= 0) continue;

                    DB::table('package_product_orders')->insert([
                        'user_id' => $user->id,
                        'package_id' => $newPackage->id,
                        'product_id' => $row['id'],
                        'package_order_id' => $userPackage->id,
                        'qty' => $qty,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }

                // Trigger matching for buyer
                $this->handleMatchingBonus($user, $ctpToAdd);

                // Referral bonus
                $this->payReferralBonus($user, $newPackage->price, $isUpgrade, $previousPackageId);
            });

            return response()->json([
                'status' => 'success',
                'message' => 'Package purchased successfully!',
                'redirect_url' => route('user.dashboard'),
            ]);

        } catch (\Exception $e) {
            \Log::error('Online purchase error', ['exception' => $e]);
            return response()->json([
                'status' => 'error',
                'message' => 'Unexpected error occurred. Please try again.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    return back()->with('error', 'Invalid payment method selected.');
}





public function purchase(Request $request)
{
    $user = Auth::user();

    // ==========================
    // 1) VALIDATION
    // ==========================
    $validator = Validator::make($request->all(), [
        'package_id'        => 'required|exists:package,id',
        'payment_method'    => 'required|in:wallet,bank,online',
        'transaction_pin'   => 'required_if:payment_method,wallet',
        'payment_proof'     => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        'acctName'          => 'nullable|string',
        'bankName'          => 'nullable|string',
        'amount'            => 'nullable|numeric',

        'product'           => 'required|array',
        'product.*.id'      => 'required|exists:product,id',
        'product.*.qty'     => 'nullable|integer|min:0',
    ]);

    if ($validator->fails()) {
        return back()->withErrors($validator)->withInput();
    }

    $newPackage = Package::find($request->package_id);
    if (!$newPackage) {
        return back()->with('error', 'Selected package not found.');
    }

    // ==========================
    // 2) VALIDATE PRODUCTS TOTALS
    // ==========================
    $maxBottles = (int) $newPackage->bottle;
    $maxCpts    = (float) $newPackage->cpts;

    $validator->after(function ($validator) use ($request, $maxBottles, $maxCpts) {

        $rows     = $request->product ?? [];
        $selected = array_filter($rows, fn($r) => !empty($r['qty']) && (int) $r['qty'] > 0);

        if (count($selected) === 0) {
            $validator->errors()->add('product', 'Please select products with valid quantities.');
            return;
        }

        $totalQty  = 0;
        $totalCpts = 0.0;

        foreach ($selected as $index => $row) {
            $qty = (int) $row['qty'];

            $product = Product::find($row['id']);
            if (!$product) {
                $validator->errors()->add("product.$index.id", 'Invalid product selected.');
                continue;
            }

            $totalQty  += $qty;
            $totalCpts += ((float) $product->cpts) * $qty;
        }

        if ($totalQty !== $maxBottles) {
            $validator->errors()->add('product', "You must select exactly {$maxBottles} bottles; you selected {$totalQty}.");
        }

        if ($totalCpts !== $maxCpts) {
            $validator->errors()->add('product', "Total CPTs must be exactly {$maxCpts}; you selected {$totalCpts}.");
        }
    });

    if ($validator->fails()) {
        return back()->withErrors($validator)->withInput();
    }

    // ==========================
    // 3) CHECK PREVIOUS PACKAGE
    // ==========================
    $previousPackage = userpackage::where('user_id', $user->id)
        ->where('status', 'approved')
        ->latest()
        ->first();

    if ($previousPackage && $newPackage->id <= $previousPackage->package_id) {
        return back()->with('error', 'You can only upgrade to a higher package.');
    }

    // ==========================
    // 4) CALCULATE AMOUNT + CPT
    // ==========================
    $amountToPay       = (float) $newPackage->price;
    $ctpToAdd          = (int) $newPackage->cpts;
    $isUpgrade         = false;
    $previousPackageId = null;

    if ($previousPackage) {
        $isUpgrade         = true;
        $previousPackageId = $previousPackage->package_id;

        $previous = Package::find($previousPackageId);

        if ($previous) {
            $amountToPay -= (float) $previous->price;
            $ctpToAdd    -= (int) $previous->cpts;
        }
    }

    // Add APC cost
    $amountToPay += ((float) $newPackage->apc * (int) $newPackage->bottle);

    // ==========================
    // 5) NORMALIZE RANK
    // ==========================
    $incentiveRanks = DB::table('incentive_settings')->pluck('rank')->toArray();
    $rankToSet      = in_array($user->user_rank, $incentiveRanks) ? $user->user_rank : 'Regular';


    // ============================================================
    // ====================== WALLET PAYMENT ======================
    // ============================================================
    if ($request->payment_method === 'wallet') {

        if ($request->transaction_pin !== $user->transaction_pin) {
            return back()->withErrors(['transaction_pin' => 'Invalid transaction PIN.'])->withInput();
        }

        if ($user->deposit_wallet_balance < $amountToPay) {
            return back()->with('error', 'Insufficient wallet balance.');
        }

        DB::transaction(function () use (
            $user,
            $newPackage,
            $previousPackageId,
            $amountToPay,
            $ctpToAdd,
            $request,
            $isUpgrade,
            $rankToSet
        ) {

            // 1) Deduct wallet ONCE (atomic)
            $user->decrement('deposit_wallet_balance', $amountToPay);

            // 2) Add buyer CPT (atomic increments)
            $user->increment('total_ctp', $ctpToAdd);
            $user->increment('p_c_cpts', $ctpToAdd);
            $user->increment('current_p_c_cpts', $ctpToAdd);
            $user->increment('current_c_cpts', $ctpToAdd);

            // 3) Update plan/status/rank
            $user->update([
                'user_plan' => $newPackage->packageName,
                'status'    => 'active',
                'user_rank' => $rankToSet,
            ]);

            // 4) Add CPT to uplines
            $this->addCTPToUplines($user, $ctpToAdd);

            // 5) Matching bonus
            $this->handleMatchingBonus($user, $ctpToAdd);

            // 6) Incentive check for direct parent
            if ($user->parent_id) {
                $parent = User::find($user->parent_id);
                if ($parent) {
                    $this->evaluateUserIncentives($parent);
                }
            }

            // 7) Create package order
            $userpackage = userpackage::create([
                'user_id'              => $user->id,
                'package_id'           => $newPackage->id,
                'previous_package_id'  => $previousPackageId,
                'amount_paid'          => $amountToPay,
                'payment_method'       => 'wallet',
                'status'               => 'approved',
                'package_order_status' => 'approved',
            ]);

            // 8) Save ordered products
            foreach ($request->product as $row) {
                $qty = (int) ($row['qty'] ?? 0);
                if ($qty <= 0) continue;

                DB::table('package_product_orders')->insert([
                    'user_id'          => $user->id,
                    'package_id'       => $newPackage->id,
                    'product_id'       => $row['id'],
                    'package_order_id' => $userpackage->id,
                    'qty'              => $qty,
                    'created_at'       => now(),
                    'updated_at'       => now(),
                ]);
            }

            // 9) Referral bonus
            $this->payReferralBonus($user, $newPackage->price, $isUpgrade, $previousPackageId);
        });

        return redirect()->route('user.package')
            ->with('success', 'Package purchased successfully using wallet.');
    }


    // ============================================================
    // ====================== BANK PAYMENT ========================
    // ============================================================
    if ($request->payment_method === 'bank') {

        if (!$request->hasFile('payment_proof')) {
            return back()->with('error', 'Please upload proof of payment.');
        }

        $image = $request->file('payment_proof');
        $filename = time() . '_' . Str::uuid() . '.' . $image->getClientOriginalExtension();
        $image->move(public_path('payment_proofs'), $filename);

        $paymentProofPath = 'payment_proofs/' . $filename;

        DB::transaction(function () use (
            $request,
            $user,
            $newPackage,
            $previousPackageId,
            $paymentProofPath
        ) {

            $userpackage = userpackage::create([
                'user_id'              => $user->id,
                'package_id'           => $newPackage->id,
                'previous_package_id'  => $previousPackageId,
                'amount_paid'          => $request->amount,
                'payment_method'       => 'bank',
                'acctName'             => $request->acctName,
                'total_amount_package' => $request->total_amount_package,
                'bankName'             => $request->bankName,
                'payment_proof'        => $paymentProofPath,
                'status'               => 'pending',
                'package_order_status' => 'pending',
            ]);

            foreach ($request->product as $row) {
                $qty = (int) ($row['qty'] ?? 0);
                if ($qty <= 0) continue;

                DB::table('package_product_orders')->insert([
                    'user_id'          => $user->id,
                    'package_id'       => $newPackage->id,
                    'product_id'       => $row['id'],
                    'package_order_id' => $userpackage->id,
                    'qty'              => $qty,
                    'created_at'       => now(),
                    'updated_at'       => now(),
                ]);
            }
        });

        return redirect()->route('user.package')
            ->with('success', 'Package submitted for approval. Awaiting admin confirmation.');
    }


    // ============================================================
    // ====================== ONLINE PAYMENT ======================
    // ============================================================
    if ($request->payment_method === 'online') {

        try {

            $request->validate([
                'paystack_reference' => 'required|string',
                'package_id'         => 'required|exists:package,id',
                'product'            => 'required|array',
                'product.*.id'       => 'required|exists:product,id',
                'product.*.qty'      => 'nullable|integer|min:0',
            ]);

            $reference        = $request->paystack_reference;
            $productSelection = $request->product;

            // Verify Paystack
            $verifyResponse = Http::withOptions(['verify' => false])
                ->withHeaders([
                    'Authorization' => 'Bearer ' . env('PAYSTACK_SECRET_KEY'),
                    'Accept'        => 'application/json',
                ])
                ->get("https://api.paystack.co/transaction/verify/{$reference}");

            if (!$verifyResponse->successful() || ($verifyResponse['data']['status'] ?? '') !== 'success') {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'Payment verification failed.',
                ], 400);
            }

            $amountPaid = $verifyResponse['data']['amount'] / 100;

            // Re-check upgrade CPT
            $ctpToAdd = (int) $newPackage->cpts;

            if ($previousPackage && $newPackage->id > $previousPackage->package_id) {
                $previous = Package::find($previousPackage->package_id);
                if ($previous) {
                    $ctpToAdd -= (int) $previous->cpts;
                }
            }

            DB::transaction(function () use (
                $user,
                $newPackage,
                $previousPackageId,
                $amountPaid,
                $ctpToAdd,
                $productSelection,
                $isUpgrade,
                $rankToSet
            ) {

                // Buyer CPT (atomic increments)
                $user->increment('total_ctp', $ctpToAdd);
                $user->increment('p_c_cpts', $ctpToAdd);
                $user->increment('current_p_c_cpts', $ctpToAdd);
                $user->increment('current_c_cpts', $ctpToAdd);

                // Status/plan/rank
                $user->update([
                    'user_plan' => $newPackage->packageName,
                    'status'    => 'active',
                    'user_rank' => $rankToSet,
                ]);

                // Uplines CPT
                $this->addCTPToUplines($user, $ctpToAdd);

                // Matching
                $this->handleMatchingBonus($user, $ctpToAdd);

                // Parent incentives
                if ($user->parent_id) {
                    $parent = User::find($user->parent_id);
                    if ($parent) {
                        $this->evaluateUserIncentives($parent);
                    }
                }

                // Package order
                $userPackage = userpackage::create([
                    'user_id'              => $user->id,
                    'package_id'           => $newPackage->id,
                    'previous_package_id'  => $previousPackageId,
                    'amount_paid'          => $amountPaid,
                    'payment_method'       => 'online',
                    'status'               => 'approved',
                    'package_order_status' => 'approved',
                ]);

                foreach ($productSelection as $row) {
                    $qty = (int) ($row['qty'] ?? 0);
                    if ($qty <= 0) continue;

                    DB::table('package_product_orders')->insert([
                        'user_id'          => $user->id,
                        'package_id'       => $newPackage->id,
                        'product_id'       => $row['id'],
                        'package_order_id' => $userPackage->id,
                        'qty'              => $qty,
                        'created_at'       => now(),
                        'updated_at'       => now(),
                    ]);
                }

                // Referral
                $this->payReferralBonus($user, $newPackage->price, $isUpgrade, $previousPackageId);
            });

            return response()->json([
                'status'       => 'success',
                'message'      => 'Package purchased successfully!',
                'redirect_url' => route('user.dashboard'),
            ]);

        } catch (\Exception $e) {

            \Log::error('Online purchase error', ['exception' => $e]);

            return response()->json([
                'status'  => 'error',
                'message' => 'Unexpected error occurred. Please try again.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    return back()->with('error', 'Invalid payment method selected.');
}





 

public function distributeCTPsToUplines($user, $cpt)
{
    $upline = User::find($user->parent_id);
    $position = $user->position;

    for ($level = 1; $upline && $level <= 10; $level++) {
        if ($position === 'left') {
            $upline->left_ctp_balance += $cpt;
        } elseif ($position === 'right') {
            $upline->right_ctp_balance += $cpt;
        }

        $upline->save();

        // Attempt matching
        $this->handleMatching($upline);

        // Move up
        $position = $upline->position;
        $upline = User::find($upline->parent_id);
    }
}


public function addCTPToUplinesnew(User $buyer, int $ctpGained): void
{
    $currentUplineId = $buyer->parent_id;
    $position        = $buyer->position; // 'left' or 'right'
    $isDirect        = true; // flag to mark the first upline only

    while ($currentUplineId) {
        $upline = User::find($currentUplineId);
        if (!$upline) break;

        // Ensure numeric defaults
        if ($upline->downline_cpt === null) $upline->downline_cpt = 0;
        if ($upline->total_ctp === null) $upline->total_ctp = 0;

        // ✅ Add CPT to overall downline_cpt
        $upline->increment('downline_cpt', $ctpGained);

        // ✅ Add CPT to total_ctp
        $upline->increment('total_ctp', $ctpGained);

        // ✅ Only the direct upline gets left/right leg CPT
        if ($isDirect) {
            if ($upline->downline_left_cpt === null) $upline->downline_left_cpt = 0;
            if ($upline->downline_right_cpt === null) $upline->downline_right_cpt = 0;

            if ($position === 'left') {
                $upline->increment('downline_left_cpt', $ctpGained);
            } elseif ($position === 'right') {
                $upline->increment('downline_right_cpt', $ctpGained);
            }

            $isDirect = false; // after first upline, stop updating leg-specific columns
        }

       $upline->increment('downline_cpt', $ctpGained);
$upline->increment('total_ctp', $ctpGained);

if ($isDirect) {
    if ($position === 'left') {
        $upline->increment('downline_left_cpt', $ctpGained);
    } elseif ($position === 'right') {
        $upline->increment('downline_right_cpt', $ctpGained);
    }
    $isDirect = false;
}
// ❌ remove $upline->save();


        // Move up the chain
        $currentUplineId = $upline->parent_id;
    }
}



public function addCTPToUplines(User $buyer, int $ctpGained): void
{
    $currentUplineId = $buyer->parent_id;
    $position        = $buyer->position; // 'left' or 'right'
    $isDirect        = true;

    while ($currentUplineId) {

        $upline = User::find($currentUplineId);
        if (!$upline) break;

        // Add CPT once
        $upline->increment('downline_cpt', $ctpGained);
        $upline->increment('total_ctp', $ctpGained);

        // Only direct upline gets leg CPT
        if ($isDirect) {
            if ($position === 'left') {
                $upline->increment('downline_left_cpt', $ctpGained);
            } elseif ($position === 'right') {
                $upline->increment('downline_right_cpt', $ctpGained);
            }
            $isDirect = false;
        }

        $currentUplineId = $upline->parent_id;
    }
}




public function addCTPToUplineslast(User $buyer, int $ctpGained): void
{
    $currentUplineId = $buyer->parent_id;
    $position        = $buyer->position; // 'left' or 'right'
    $isDirect        = true;

    while ($currentUplineId) {
        $upline = User::find($currentUplineId);
        if (!$upline) break;

        // Ensure numeric defaults
        if ($upline->downline_cpt === null) $upline->downline_cpt = 0;
        if ($upline->total_ctp === null) $upline->total_ctp = 0;

        // Atomic increments
        $upline->increment('downline_cpt', $ctpGained);
        $upline->increment('total_ctp', $ctpGained);

        // Direct upline leg-specific CPT
        if ($isDirect) {
            if ($upline->downline_left_cpt === null) $upline->downline_left_cpt = 0;
            if ($upline->downline_right_cpt === null) $upline->downline_right_cpt = 0;

            if ($position === 'left') {
                $upline->increment('downline_left_cpt', $ctpGained);
            } elseif ($position === 'right') {
                $upline->increment('downline_right_cpt', $ctpGained);
            }

            $isDirect = false;
        }

        // ❌ Do not call $upline->save() here — increments already persist
        $currentUplineId = $upline->parent_id;
    }
}










public function evaluateUserIncentives(User $user): void
{
    // Pull incentive settings from DB
    $ranks = DB::table('incentive_settings')
        ->orderBy('required_ctp', 'asc') // ensure ascending order
        ->get();

    foreach ($ranks as $r) {
        // 1. Check parent’s total downline CPT
        if ($user->downline_cpt < $r->required_ctp) continue;

        // 2. Count direct downlines with required rank
        $downlines = User::where('parent_id', $user->id)
            ->where('user_rank', $r->required_downline_rank)
            ->pluck('total_ctp')
            ->toArray();

        if (count($downlines) < $r->required_downline_count) continue;

        // 3. Sort by CPT descending and take top N
        rsort($downlines);
        $topSum = array_sum(array_slice($downlines, 0, $r->required_downline_count));

        // 4. Check if they meet required CPT
        if ($topSum >= $r->required_ctp) {
            $user->user_rank = $r->rank;
            $user->save();

            incentives::updateOrCreate(
                ['user_id' => $user->id, 'rank' => $r->rank],
                ['status' => 'achieved', 'achieved_at' => now()]
            );

            break; // stop at highest achieved rank
        }
    }
}




public function evaluateUserIncentivesold(User $user): void
{
    $ranks = [
        ['rank' => 'Crystal',  'ctp' => 1100,     'required_rank' => 'Regular'],
        ['rank' => 'Bronze',   'ctp' => 3300,     'required_rank' => 'Crystal'],
        ['rank' => 'Silver',   'ctp' => 32000,    'required_rank' => 'Bronze'],
        ['rank' => 'Ruby',     'ctp' => 120000,   'required_rank' => 'Silver'],
        ['rank' => 'Sapphire', 'ctp' => 450000,   'required_rank' => 'Ruby'],
        ['rank' => 'Gold',     'ctp' => 1200000,  'required_rank' => 'Sapphire'],
        ['rank' => 'Diamond',  'ctp' => 3000000,  'required_rank' => 'Gold'],
    ];

    foreach ($ranks as $r) {
        // Get direct downlines
        $downlines = User::where('parent_id', $user->id)
            ->where('user_rank', $r['required_rank'])
            ->pluck('total_ctp')
            ->toArray();

        if (count($downlines) < 2) continue;

        // Sort by CPT descending
        rsort($downlines);

        // Take top 2 downlines
        $topTwoSum = $downlines[0] + $downlines[1];

        // Check if they meet required CPT
        if ($topTwoSum >= $r['ctp']) {
            $user->user_rank = $r['rank'];
            $user->save();

            incentives::updateOrCreate(
                ['user_id' => $user->id, 'rank' => $r['rank']],
                ['status' => 'achieved', 'achieved_at' => now()]
            );

            break; // stop at highest achieved rank
        }
    }
}








private function updateUplineLegCtp(User $user, int $ctp)
{
    if (!$user->parent_id || !$user->position) {
        return;
    }

    $upline = User::find($user->parent_id);
    if (!$upline) return;

    if ($user->position === 'left') {
        $upline->left_ctp_for_matching += $ctp;
    } elseif ($user->position === 'right') {
        $upline->right_ctp_for_matching += $ctp;
    }

    $upline->save();
}


 



public function handleMatchingBonus(User $user, $ctpGained, $generation = 1, $side = null)
{
    \Log::info("==== [MATCHING START] ==== User: {$user->username} | Gained: {$ctpGained} CPT | Gen: {$generation}");

    // Stop at 9 generations
    if ($generation > 9 || !$user->parent_id) {
        return;
    }

    // Parent/upline at this generation
    $upline = User::find($user->parent_id);
    if (!$upline) return;

    // Always derive placement side from the child relative to THIS upline
    // This ensures: 
    // - tester04 activity → tester02 left (because tester04.position == 'left')
    // - tester05 activity → tester02 right
    // - tester02 activity → tester01 left (because tester02.position == 'left')
    $currentSide = strtolower($user->position);

    if (!in_array($currentSide, ['left', 'right'])) {
        \Log::warning("Invalid side '{$currentSide}' for user {$user->username}");
        // Recurse upward anyway, preserving CPT flow (no add on invalid side)
        return $this->handleMatchingBonus($upline, $ctpGained, $generation + 1, $currentSide);
    }

    // Check sponsor structure (preserved)
    $hasLeftSponsor = User::where('sponsor_id', $upline->id)->where('position', 'left')->exists();
    $hasRightSponsor = User::where('sponsor_id', $upline->id)->where('position', 'right')->exists();

    // Add CPT strictly to the placement leg at this level,
    // but only if that leg has at least one sponsored user (preserved gate).
    // This naturally splits under the direct upline (tester02 receives left for tester04, right for tester05)
    // and flows to a single leg for higher uplines (tester01 receives only left because tester02.position == 'left').
    $added = false;
    if ($currentSide === 'left' && $hasLeftSponsor) {
        $upline->left_ctp_for_matching += $ctpGained;
        $added = true;
    } elseif ($currentSide === 'right' && $hasRightSponsor) {
        $upline->right_ctp_for_matching += $ctpGained;
        $added = true;
    }

    if (!$added) {
        \Log::info("🚫 No CPT added — {$upline->username} has no sponsored user on {$currentSide} leg.");
        // Continue upward with the upline as the child for the next level
        return $this->handleMatchingBonus($upline, $ctpGained, $generation + 1, $currentSide);
    }

    $upline->save();

    $left  = $upline->left_ctp_for_matching;
    $right = $upline->right_ctp_for_matching;
    $pairCPT = 16;

    // Must have CPT on both legs AND both legs sponsored to match (preserved)
    if (!$hasLeftSponsor || !$hasRightSponsor || $left < $pairCPT || $right < $pairCPT) {
        return $this->handleMatchingBonus($upline, $ctpGained, $generation + 1, $currentSide);
    }

    // Determine number of possible pairs
    $possiblePairs = floor(min($left, $right) / $pairCPT);

    // Fetch active package (preserved)
    $activePackage = \App\Models\UserPackage::where('user_id', $upline->id)
        ->where('status', 'approved')
        ->latest('created_at')
        ->first();

    if (!$activePackage) {
        return $this->handleMatchingBonus($upline, $ctpGained, $generation + 1, $currentSide);
    }

    $package = \App\Models\Package::find($activePackage->package_id);
    if (!$package) {
        return;
    }

    // Use LIMIT + PERCENTAGE (preserved map)
    $map = [
        'standard'  => ['limit' => 20,  'percentage' => 7],
        'basic'     => ['limit' => 30,  'percentage' => 9],
        'classic'   => ['limit' => 40,  'percentage' => 12],
        'premium'   => ['limit' => 60,  'percentage' => 13],
        'executive' => ['limit' => 75,  'percentage' => 14],
        'vip'       => ['limit' => 100, 'percentage' => 15],
    ];

    $key = strtolower($package->packageName);
    $matchLimitPairs = $map[$key]['limit'] ?? 0;
    $matchPercentage = $map[$key]['percentage'] ?? 0;

    // Check how many pairs already paid today (preserved)
    $dailyMatchedCount = \App\Models\Bonus::where('user_id', $upline->id)
        ->where('type', 'matching')
        ->whereDate('created_at', now())
        ->count();

    $remainingPairsAllowedToday = max(0, $matchLimitPairs - $dailyMatchedCount);

    // CPT MUST ALWAYS BE DEDUCTED for all computed pairs (preserved)
    $usedCPT = $possiblePairs * $pairCPT;

    $upline->left_ctp_for_matching  = max(0, $upline->left_ctp_for_matching  - $usedCPT);
    $upline->right_ctp_for_matching = max(0, $upline->right_ctp_for_matching - $usedCPT);
    $upline->save();

    $baseAmount = 24000;

    // Pay per pair with remaining daily cap (preserved)
    for ($i = 0; $i < $possiblePairs; $i++) {

        if ($i < $remainingPairsAllowedToday) {
            // Pay bonus
            $amount = $baseAmount * ($matchPercentage / 100);
            $upline->withdraw_wallet_balance += $amount;
            $upline->save();
        } else {
            // Daily limit reached — no bonus paid
            $amount = 0;
        }

        // Record bonus for each pair (preserved)
        \App\Models\Bonus::create([
            'user_id'     => $upline->id,
            'amount'      => $amount,
            'type'        => 'matching',
            'is_paid'     => 1,
            'description' => "Matching payout for 1 pair — CPT deducted {$pairCPT}",
            'is_approved' => false,
        ]);
    }

    // Continue recursion with upline as the child for the next level
    return $this->handleMatchingBonus($upline, $ctpGained, $generation + 1, null);
}













public function distributeCtpAnd23TriggerMatching23(User $user, int $ctpGained)
{
    $currentUser = $user;
    $generation = 1;

    while ($currentUser->parent_id && $generation <= 10) {
        $upline = User::find($currentUser->parent_id);
        if (!$upline) break;

        $side = strtolower($currentUser->position); // 'left' or 'right'

        //  Add CPT to correct leg
        if ($side === 'left') {
            $upline->left_ctp_for_matching += $ctpGained;
        } elseif ($side === 'right') {
            $upline->right_ctp_for_matching += $ctpGained;
        }

        //  Add to total CPT
        $upline->total_ctp += $ctpGained;
        $upline->save();

        //  Trigger matching for this upline
        $this->handleMatchingBonus($upline, $ctpGained, $generation);

        $currentUser = $upline;
        $generation++;
    }

    //  Also trigger matching for the buyer
    $this->handleMatchingBonus($user, $ctpGained, 1);
}



 


public function addCTPTo20Uplines(User $user, int $ctpGained)
{
    $currentUplineId = $user->parent_id;
    $position = $user->position; // 'left' or 'right'
    $generation = 1;

    while ($currentUplineId && $generation <= 10) {
        $upline = User::find($currentUplineId);
        if (!$upline) break;

        //  Add to total CPT
        $upline->increment('total_ctp', $ctpGained);

        //  Add CPT to correct leg
        if ($position === 'left') {
            $upline->left_ctp_for_matching += $ctpGained;
        } elseif ($position === 'right') {
            $upline->right_ctp_for_matching += $ctpGained;
        }

        $upline->save();

        //  Trigger matching bonus
        $this->handleMatchingBonus($upline, $ctpGained, $generation);

        // Move up the tree
        $position = $upline->position; // get upline's position relative to their own parent
        $currentUplineId = $upline->parent_id;
        $generation++;
    }
}


public function payReferralBonus($user, float $amount, bool $isUpgrade = false, $previousPackageId = null): void
{
    $sponsor = $user->sponsor_id ? User::find($user->sponsor_id) : null;
    $levels = [21, 2, 1, 1]; // % per level
    $level = 0;

    \Log::info("==> Starting payReferralBonus for user ID {$user->id} | Amount: {$amount} | IsUpgrade: " . ($isUpgrade ? 'Yes' : 'No'));

    while ($sponsor && $level < 4) {
        $percentage = $levels[$level];

        // Skip non-direct upgrade
        if ($isUpgrade && $level > 0) {
            break;
        }

        // On registration: skip level 2-4 if sponsor has standard or no plan
        if (!$isUpgrade && $level > 0 && (empty($sponsor->user_plan) || strtolower($sponsor->user_plan) === 'standard')) {
            \Log::info("Skipping level " . ($level + 1) . " sponsor ID {$sponsor->id} due to plan: {$sponsor->user_plan}");
            $sponsor = $sponsor->sponsor_id ? User::find($sponsor->sponsor_id) : null;
            $level++;
            continue;
        }

        // Calculate bonus
        if ($isUpgrade && $level === 0) {
            $oldAmount = 0;
            if ($previousPackageId) {
                $old = Package::find($previousPackageId);
                $oldAmount = $old ? $old->price : 0;
            }
            $bonusAmount = ($amount - $oldAmount) * 22 / 100;
            $type = 'upgrade';
            $description = "Upgrade bonus from user {$user->username}";
        } else {
            $bonusAmount = $amount * ($percentage / 100);
            $type = 'referral';
            $description = "Referral bonus from level " . ($level + 1) . " user {$user->username}";
        }

        // Credit bonus
        $sponsor->withdraw_wallet_balance += $bonusAmount;
        $sponsor->save();

        // Save record
        Bonus::create([
            'user_id' => $sponsor->id,
            'amount' => $bonusAmount,
            'type' => $type,
            'is_paid' => '1',
            'description' => $description,
        ]);

        \Log::info("Paid {$type} bonus of ₦{$bonusAmount} to sponsor ID {$sponsor->id} (level " . ($level + 1) . ")");

        $sponsor = $sponsor->sponsor_id ? User::find($sponsor->sponsor_id) : null;
        $level++;
    }
}


public function saveSelectedProducts(Request $request, $package_id)
{
    $package    = Package::findOrFail($package_id);
    $user       = Auth::user();
    $maxBottles = (int) $package->bottle;
    $maxCpts    = (float) $package->cpts;

    $validator = Validator::make($request->all(), [
        'product'       => 'required|array',
        'product.*.id'  => 'required|exists:product,id',
        'product.*.qty' => 'nullable|integer|min:0',
    ]);



$validator->after(function ($validator) use ($request, $maxBottles, $maxCpts) {
    $rows = $request->product ?? [];
    $selected = array_filter($rows, fn ($r) => !empty($r['qty']) && (int)$r['qty'] > 0);

    if (count($selected) === 0) {
        $validator->errors()->add('product', 'Please select products with valid quantities.');
        return;
    }

    $totalQty  = 0;
    $totalCpts = 0.0;

    foreach ($selected as $index => $row) {
        $qty = (int) $row['qty'];
        $product = Product::find($row['id']);
        if (!$product) {
            $validator->errors()->add("product.$index.id", 'Invalid product selected.');
            continue;
        }

        $totalQty  += $qty;
        $totalCpts += ((float) $product->cpts) * $qty;
    }

    //  Enforce exact bottles (not less, not more)
    if ($totalQty !== $maxBottles) {
        $validator->errors()->add('product', "You must select exactly {$maxBottles} bottles; you selected {$totalQty}.");
    }

    //  Ensure CPTs do not exceed the package limit
    if ($totalCpts > $maxCpts) {
        $validator->errors()->add('product', "Total selected CPTs ({$totalCpts}) exceeds your package CPTs ({$maxCpts}).");
    }
});


    if ($validator->fails()) {
        return back()->withErrors($validator)->withInput();
    }

    DB::transaction(function () use ($request, $user, $package_id) {

        // Save items (use your existing table)
        foreach ($request->product as $row) {
            $qty = (int) ($row['qty'] ?? 0);
            if ($qty <= 0) continue;

            DB::table('package_product_orders')->insert([
                'user_id'    => $user->id,
                'package_id' => $package_id,
                'product_id' => $row['id'],
                'qty'        => $qty,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        // Flip the latest pending userpackage for this user+package to APPROVED (product selection done)
        $pendingUP = userpackage::where('user_id', $user->id)
            ->where('package_id', $package_id)
            ->where('package_order_status', 'pending')
            ->latest('id')
            ->first();

        if ($pendingUP) {
            $pendingUP->package_order_status = 'approved';
            $pendingUP->save();
        }
    });

    return redirect()->route('user.package')
        ->with('success', 'Products selected successfully. Your package order is now complete.');
}


 



}
